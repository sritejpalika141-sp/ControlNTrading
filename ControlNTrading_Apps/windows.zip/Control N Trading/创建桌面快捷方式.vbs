Set ws = CreateObject("WScript.Shell")
Set sc = ws.CreateShortcut(ws.SpecialFolders("Desktop") & "\Control N Trading.lnk")
sc.TargetPath = ws.CurrentDirectory & "\Control N Trading.bat"
sc.WorkingDirectory = ws.CurrentDirectory
sc.IconLocation = ws.CurrentDirectory & "\icon.ico"
sc.Description = "Control N Trading - WebToApp"
sc.Save
WScript.Echo "桌面快捷方式已创建！"
