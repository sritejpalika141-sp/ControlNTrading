@echo off
title Control N Trading
set "URL=https://controlntrading.online/"
(where msedge >nul 2>&1) && (start "" msedge --app="%URL%" --new-window & exit /b)
(where chrome >nul 2>&1) && (start "" chrome --app="%URL%" --new-window & exit /b)
start "" "%URL%"
